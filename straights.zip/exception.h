class Exception {

};
